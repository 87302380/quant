"""Frozen exploratory controls; original X8 remains unchanged."""
from datetime import timedelta
from pathlib import Path
import sys

from freqtrade.strategy import stoploss_from_absolute

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'study'))
from NFI24Hour import NFI24Hour


class NFIRiskStop3(NFI24Hour):
    use_custom_stoploss = True
    adverse_price_fraction = .03

    def custom_stoploss(self, pair, trade, current_time, current_rate, current_profit,
                        after_fill=False, **kwargs):
        entries = trade.select_filled_orders(trade.entry_side)
        first = entries[0].safe_price if entries else trade.open_rate
        stop = first * (1 + self.adverse_price_fraction if trade.is_short else 1 - self.adverse_price_fraction)
        return stoploss_from_absolute(stop, current_rate, is_short=trade.is_short, leverage=trade.leverage)

    def confirm_trade_exit(self, pair, trade, order_type, amount, rate, time_in_force,
                           exit_reason, current_time, **kwargs):
        if exit_reason in ('stop_loss', 'trailing_stop_loss'):
            return True
        return super().confirm_trade_exit(pair, trade, order_type, amount, rate, time_in_force,
                                          exit_reason, current_time, **kwargs)


class NFIRiskStop6(NFIRiskStop3):
    adverse_price_fraction = .06


class NFIRiskStale12(NFI24Hour):
    stale_reason = 'research_negative_after_12h'

    def stale(self, trade, now, rate):
        if now < trade.open_date_utc + timedelta(hours=12):
            return False
        entries = trade.select_filled_orders(trade.entry_side)
        exits = trade.select_filled_orders(trade.exit_side)
        return self.calc_total_profit(trade, entries, exits, rate)[0] < 0

    def custom_exit(self, pair, trade, current_time, current_rate, current_profit, **kwargs):
        if not self.expired(trade, current_time) and self.stale(trade, current_time, current_rate):
            return self.stale_reason
        return super().custom_exit(pair, trade, current_time, current_rate, current_profit, **kwargs)

    def adjust_trade_position(self, trade, current_time, current_rate, *args, **kwargs):
        if self.expired(trade, current_time) or self.stale(trade, current_time, current_rate):
            return None
        return super().adjust_trade_position(trade, current_time, current_rate, *args, **kwargs)

    def confirm_trade_exit(self, pair, trade, order_type, amount, rate, time_in_force,
                           exit_reason, current_time, **kwargs):
        if exit_reason == self.stale_reason:
            return True
        return super().confirm_trade_exit(pair, trade, order_type, amount, rate, time_in_force,
                                          exit_reason, current_time, **kwargs)


class NFIRiskTrendGate(NFI24Hour):
    def populate_entry_trend(self, dataframe, metadata):
        dataframe = super().populate_entry_trend(dataframe, metadata)
        long_ok = (dataframe['EMA_12_4h'] > dataframe['EMA_200_4h']) & (dataframe['close'] > dataframe['EMA_200_4h'])
        short_ok = (dataframe['EMA_12_4h'] < dataframe['EMA_200_4h']) & (dataframe['close'] < dataframe['EMA_200_4h'])
        dataframe.loc[~long_ok, 'enter_long'] = 0
        dataframe.loc[~short_ok, 'enter_short'] = 0
        return dataframe
